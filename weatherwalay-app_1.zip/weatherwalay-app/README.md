# WeatherWalay Stations Monitor: APK project

Contents: `www/` (the app: index.html, manifest, service worker, icons), `assets/` (logo sources for the Android icon), `capacitor.config.json`, `package.json`, and a GitHub Actions workflow that builds the APK for you.

NOTE: `www/index.html` currently shows SAMPLE data. Connect your real API calls before releasing.

## Easiest: build the APK in the cloud (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the repo's Actions tab, choose "Build APK", then Run workflow (it also runs on every push).
4. When it finishes (about 5 minutes), open the run and download the artifact `WeatherWalay-debug-apk`. Unzip it, copy `app-debug.apk` to your phone, and install it (allow "Install unknown apps").

## Build on your own computer
Install Node 20+, JDK 17 and Android Studio (for the Android SDK), then:
```
npm install
npx cap add android
npm run icons
npx cap sync android
cd android && ./gradlew assembleDebug      # Windows: gradlew.bat assembleDebug
```
The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Release (Play Store or sharing widely)
Debug APKs are fine for testing. For release, in Android Studio use Build, then Generate Signed Bundle / APK, create a keystore, and KEEP IT SAFE. You need the same keystore for every future update.

## Updating the app
Edit `www/index.html`, run `npx cap sync android`, rebuild. Or push to GitHub and the workflow rebuilds.

## Optional: use as a website/PWA
Deploy `www/` to Cloudflare Pages (build output directory `www`). The manifest and service worker make it installable from the browser.

## Connecting real data
Replace the sample data (the `ST`, `ISS` and `RG` arrays in `index.html`) with fetch() calls to your API. If the API is on another domain, it must allow CORS.
